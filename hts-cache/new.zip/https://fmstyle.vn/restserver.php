
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title></title>
  <meta property="og:image" content="https://cdn.pancake.vn/files/d0/b0/d3/a7/092015619b7cd6a9f96e9d62ee105a63f0908a3b175f94d7b8f51f9d.jpg">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">
  <meta property="og:site_name" content="">
  <meta property="og:url" content="">
  <meta property="og:title" content="">
  <meta property="og:type" content="">
  <meta property="og:description" content="">
  <meta name="description" content=""/>
  <meta name="facebook-domain-verification" content="dla141c149a7hl34j2bv8is9dkltuu" />
    
  <link rel="stylesheet" href="/file/assets?key=assets%2Fmain.css&v=1638333343">
  <!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>-->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
  <link href="https://fonts.googleapis.com/css?family=Alegreya+Sans&display=swap" rel="stylesheet" />
  <link rel="shortcut icon" type="image/png" href="https://scontent.fdad1-1.fna.fbcdn.net/v/t1.6435-9/163128248_792837528018717_1908464404751329134_n.png?_nc_cat=1&ccb=1-3&_nc_sid=09cbfe&_nc_ohc=91b7dS5kLi8AX9qrrjP&_nc_ht=scontent.fdad1-1.fna&oh=7092aad2d540fbc586ce21aa4d78d2fc&oe=60AF0C00"/>
  <!-- OWL -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" />

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
  <script type="text/javascript" src="https://statics.pancake.vn/web-assets/1689/64/fb/c7/f8/jquery-lazy-min.js"></script>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.css">
  <script src="https://analytics.pancake.vn/vendor/analytics.js"></script>
  <script>
    (function(w, t) {
      window.PancakeAnalytics = w.PancakeAnalytics || {}
      window.PancakeAnalytics.init(t)
    })(window, "pa-3535")
  </script>

  <!-- Facebook Pixel Code -->
    <script>
      !function(f,b,e,v,n,t,s)
      {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
      n.callMethod.apply(n,arguments):n.queue.push(arguments)};
      if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
      n.queue=[];t=b.createElement(e);t.async=!0;
      t.src=v;s=b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t,s)}(window, document,'script',
      'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', '416842036226667 '); fbq('init', '121999280007843 '); fbq('init', '209246013913761 '); fbq('init', '219574300028083 '); fbq('init', '1219916038468493 '); 

      fbq('track', 'PageView');
      
      
    </script>
  <!-- End Facebook Pixel Code -->



</head>

<body>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-zoom/1.7.20/jquery.zoom.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.touchswipe/1.6.19/jquery.touchSwipe.min.js"></script>
  <script type="application/json" id="login-logout">null</script>
  <script type="application/json" id="TemplateJson">null</script>
  
  
  
    <div class="phonering-alo-phone phonering-alo-green phonering-alo-show" id="phonering-alo-phoneIcon" style="left: -50px; bottom: 150px; position: fixed;">
      <div class="phonering-alo-ph-circle"></div>
      <div class="phonering-alo-ph-circle-fill"></div>
      <a href="tel:++84901800888"></a>
      <div class="phonering-alo-ph-img-circle">
        <a href="tel:++84901800888"></a>
        <a href="tel:++84901800888" class="pps-btn-img " title="Liên hệ">
          <img src="https://i.imgur.com/v8TniL3.png" alt="Liên hệ" width="50" onmouseover="this.src='https://i.imgur.com/v8TniL3.png';" onmouseout="this.src='https://i.imgur.com/v8TniL3.png';">
        </a>
      </div>
    </div>
    
    
  
  
  <!-- Start header -->
<div class="header-fixed">
  <div class="wrapper">
    <div class="container header-container ">
    <div class="logo hidden-md">
      <a href="/">
        <img src="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" data-lazyload="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" alt="logo Cheapstore">
      </a>
    </div>
    <nav class="hidden-lg">
        <ul class="nav">
          
          
            
            
              <li class="lvl1 sidebar-menu-item ">
                <a class="pdlr-16 pdtb-8 color-white" href="https://anhtung.pancake.vn/">TRANG CHỦ </a>
                
              </li>
              
            
            
              <li class="lvl1 sidebar-menu-item has-mega">
                <a class="pdlr-16 pdtb-8 color-white" href="/categories/do-nam">NAM <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                
                  <div class="row mega-content">
                    <div class="col md-fix-20">
                      <ul class="row" style="justify-content: space-around;">
                         <li class="sidebar-menu-item " style="display: flex; flex-direction: column;">
                           
                          </li>
                      </ul>
                    </div>
                    <div class="col md-fix-60">
                      <ul class="row" style="justify-content: flex-start;">
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-thun-nam">Áo Thun Nam</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-so-mi-nam">Áo Sơ Mi Nam</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-len-nam">Áo Len Nam</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-khoac-nam">Áo Khoác Nam</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/quan-short-nam">Quần Short Nam</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/quan-jean-nam">Quần Jeans Nam</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/quan-tay-nam">Quần Tây Nam</a>
                            
                          </li>
                        </div>
                          
                        
                      </ul>
                    </div>
                    <div class="big-image-header col md-fix-20">
                        <a href=""><img src="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" data-lazyload="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" alt="Sản phẩm" class="img-responsive center-block"></a>
                    </div>
                  </div>
                
              </li>
              
            
            
              <li class="lvl1 sidebar-menu-item has-mega">
                <a class="pdlr-16 pdtb-8 color-white" href="/categories/do-nu">NỮ <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                
                  <div class="row mega-content">
                    <div class="col md-fix-20">
                      <ul class="row" style="justify-content: space-around;">
                         <li class="sidebar-menu-item " style="display: flex; flex-direction: column;">
                           
                          </li>
                      </ul>
                    </div>
                    <div class="col md-fix-60">
                      <ul class="row" style="justify-content: flex-start;">
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-thun-nu">Áo Thun Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-so-mi-nu">Áo Sơ Mi Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-kieu">Áo Kiểu</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-len-nu">Áo Len Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-khoac-nu">Áo Khoác Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/quan-short-nu">Quần Short Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/quan-tay-nu">Quần Tây Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/quan-jean-nu">Quần Jeans Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/chan-vay">Chân Váy</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/yem">Yếm</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/vay-dam">Váy Đầm</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/set-bo">Set Bộ</a>
                            
                          </li>
                        </div>
                          
                        
                      </ul>
                    </div>
                    <div class="big-image-header col md-fix-20">
                        <a href=""><img src="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" data-lazyload="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" alt="Sản phẩm" class="img-responsive center-block"></a>
                    </div>
                  </div>
                
              </li>
              
            
            
              <li class="lvl1 sidebar-menu-item has-mega">
                <a class="pdlr-16 pdtb-8 color-white" href="/categories/tre-em">Trẻ em <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                
                  <div class="row mega-content">
                    <div class="col md-fix-20">
                      <ul class="row" style="justify-content: space-around;">
                         <li class="sidebar-menu-item " style="display: flex; flex-direction: column;">
                           
                          </li>
                      </ul>
                    </div>
                    <div class="col md-fix-60">
                      <ul class="row" style="justify-content: flex-start;">
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/be-trai">Bé Trai</a>
                            
                              <ul>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/ao-so-mi-be-trai" font-weight:"600">Áo sơ mi</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/ao-thun-be-trai" font-weight:"600">Áo thun</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/quan-dai-be-trai" font-weight:"600">Quần dài</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/quan-short-be-trai" font-weight:"600">Quần short</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/set-bo-be-trai" font-weight:"600">Set bộ</a>
                                  </li>
                                
                              </ul>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/be-gai">Bé Gái</a>
                            
                              <ul>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/so-mi-ao-kieu-be-gai" font-weight:"600">Sơ mi - Áo kiểu</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/ao-thun-be-gai" font-weight:"600">Áo thun</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/vay-dam-be-gai" font-weight:"600">Váy - Đầm</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/quan-dai-be-gai" font-weight:"600">Quần dài</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/quan-short-be-gai" font-weight:"600">Quần short</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/set-bo-be-gai" font-weight:"600">Set bộ</a>
                                  </li>
                                
                              </ul>
                            
                          </li>
                        </div>
                          
                        
                      </ul>
                    </div>
                    <div class="big-image-header col md-fix-20">
                        <a href=""><img src="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" data-lazyload="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" alt="Sản phẩm" class="img-responsive center-block"></a>
                    </div>
                  </div>
                
              </li>
              
            
            
              <li class="lvl1 sidebar-menu-item ">
                <a class="pdlr-16 pdtb-8 color-white" href="/categories/couple">Couple </a>
                
              </li>
              
            
            
              <li class="lvl1 sidebar-menu-item ">
                <a class="pdlr-16 pdtb-8 color-white" href="/categories/phu-kien">PHỤ KIỆN </a>
                
              </li>
              
            
            
              <li class="lvl1 sidebar-menu-item has-mega">
                <a class="pdlr-16 pdtb-8 color-white" href="https://anhtung.pancake.vn/pages/gioi-thieu-cong-ty">FM STYLE <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                
                  <div class="row mega-content">
                    <div class="col md-fix-20">
                      <ul class="row" style="justify-content: space-around;">
                         <li class="sidebar-menu-item " style="display: flex; flex-direction: column;">
                           
                          </li>
                      </ul>
                    </div>
                    <div class="col md-fix-60">
                      <ul class="row" style="justify-content: flex-start;">
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="https://anhtung.pancake.vn/pages/lich-su-hinh-thanh">Lịch Sử Hình Thành</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="https://fmstyle.com.vn/pages/vien-canh">Tầm Nhìn</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="https://fmstyle.com.vn/pages/su-menh">Sứ Mệnh</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="https://anhtung.pancake.vn/pages/van-hoa-cong-ty">Văn Hoá Công Ty</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="https://anhtung.pancake.vn/pages/danh-sach-dia-chi-cua-hang">Danh Sách Chi Nhánh</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="https://anhtung.pancake.vn/pages/ban-giam-doc">Ban Giám Đốc</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/pages/gia-tri-cot-loi">Giá Trị Cốt Lõi</a>
                            
                          </li>
                        </div>
                          
                        
                      </ul>
                    </div>
                    <div class="big-image-header col md-fix-20">
                        <a href=""><img src="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" data-lazyload="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" alt="Sản phẩm" class="img-responsive center-block"></a>
                    </div>
                  </div>
                
              </li>
              
            
            
              <li class="lvl1 sidebar-menu-item has-mega">
                <a class="pdlr-16 pdtb-8 color-white" href="/blog">TIN TỨC <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                
                  <div class="row mega-content">
                    <div class="col md-fix-20">
                      <ul class="row" style="justify-content: space-around;">
                         <li class="sidebar-menu-item " style="display: flex; flex-direction: column;">
                           
                          </li>
                      </ul>
                    </div>
                    <div class="col md-fix-60">
                      <ul class="row" style="justify-content: flex-start;">
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/blog/tips-thoi-trang">TIPS THỜI TRANG</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/blog/chuong-trinh-sale">CHƯƠNG TRÌNH SALE</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/blog/goc-gop-y">GÓC GÓP Ý</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/blog/tuyen-dung">TUYỂN DỤNG</a>
                            
                          </li>
                        </div>
                          
                        
                      </ul>
                    </div>
                    <div class="big-image-header col md-fix-20">
                        <a href=""><img src="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" data-lazyload="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" alt="Sản phẩm" class="img-responsive center-block"></a>
                    </div>
                  </div>
                
              </li>
              
            
          
        
          
        
          
        
          
        
        </ul>
    </nav>
    <div class="from-right is-flex hidden-md">
      <div class="cart-box">
        <a href="/cart">
          <div class="cart-box-btn pos-relative"><i class="fa fa-cart-arrow-down pos-relative"></i><span class="pos-absolute">0</span></div>
        </a>
      </div>
    </div>
	</div>
  </div>
</div>

<header>
  <div class="wrapper">
    <div class="container">
			<!-- Topbar -->
      <div class="topbar is-splitter hidden-md">
        <div class="from-left is-flex">
          <span class="hotline-header">
            <a style="color: #fbfbfb" href="tel:0901.800.888">
              <span class="circle-phone"><i class="fa fa-phone" aria-hidden="true"></i></span>
              <span>Hotline: 0901.800.888</span>
            </a>
          </span>
        </div>
        <div class="from-right is-flex">
          <div class="search-wrapper mgr-10">
            <form class="search mgl-10">
              <input name="q" type="text" placeholder="Tìm kiếm…" autocomplete="off" class="input_search">
              <div class="search-icon" id="search-big">
                <i class="fa fa-search" aria-hidden="true"></i>
              </div>
            </form>
          </div>
        <script>
          $("#search-big").click(function(){
            window.location.assign("/search?q="+$(".search .input_search").val())
          });
          
          $('.input_search').bind("enterKey",function(e){
           window.location.assign("/search?q="+$(".search .input_search").val())
          });
          $('.input_search').keyup(function(e){
              if(e.keyCode == 13)
              {
                  $(this).trigger("enterKey");
              }
          });
        </script>
          <div class="mgr-14 sign">
            <a href="/customer/login" class="color-white">
              <i class="fa fa-sign-in" aria-hidden="true"></i> Đăng nhập
            </a>
          </div>
          <div class="sign">
            <a href="/customer/register" class="color-white">
              <i class="fa fa-user-plus" aria-hidden="true"></i> Đăng kí
            </a>  
          </div>
          <div class="signout mgr-14">
            <a href="/customer/account" class="color-white">
               
            </a>  
          </div>
          <div class="signout">
            <a href="/customer/logout" class="color-white">
               <i class="fa fa-sign-out"></i> Thoát
            </a>  
          </div>
        </div>
      </div>
      <script>
        obj = JSON.parse(document.getElementById('login-logout').innerText);
        if(obj != null) {
           let x = document.querySelectorAll('.sign')
           for (let i = 0 ; i< x.length; i++)  x[i].style.display = "none"
           let y = document.querySelectorAll('.signout')
           for (let i = 0 ; i< y.length; i++) y[i].style.display = "block"
            
          } else {
            let y = document.querySelectorAll('.signout')
            for (let i = 0 ; i< y.length; i++)  y[i].style.display = "none"
          }
      </script>
			<!-- End Topbar -->
			
			<div class="header-container-mobile hidden-md-up">
        <div class="hamburger" id="toogle-sidebar">
          <i class="fa fa-bars" aria-hidden="true"></i>
        </div>

        <div class="logo-mobile hidden-md-up">
        <a href="/">
          <img src="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" data-lazyload="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" alt="logo Cheapstore"></a>
        </div>
        
        <div class="icon-right">
          <div class="search-mobile">
            <div class="icon-search">
              <i class="fa fa-search" aria-hidden="true"></i>
            </div>
          </div>
          <div class="cart-box">
  				<a href="/cart">
  					<div class="cart-box-btn color-white pos-relative">
  					  <i class="fa fa-cart-arrow-down"></i>
  					  <span class="pos-absolute">0</span>
					  </div>
  				</a>
  			  </div>
        </div>
      </div>

			<!-- Start header container -->
			<div class="header-container ">
        <div class="logo hidden-md">
          <a href="/">
            <img src="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" data-lazyload="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" alt="logo Cheapstore">
          </a>
        </div>
        <nav class="hidden-lg">
            <ul class="nav">
          
          
            
            
            
              <li class="lvl1 sidebar-menu-item ">
                <a class="pdlr-16 pdtb-8 color-white" href="https://anhtung.pancake.vn/">TRANG CHỦ </a>
                
              </li>
              
            
            
            
              <li class="lvl1 sidebar-menu-item has-mega">
                <a class="pdlr-16 pdtb-8 color-white" href="/categories/do-nam">NAM <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                
                  <div class="row mega-content">
                    <div class="col md-fix-20">
                      <ul class="row" style="justify-content: space-around;">
                         <li class="sidebar-menu-item " style="display: flex; flex-direction: column;">
                           
                          </li>
                      </ul>
                    </div>
                    <div class="col md-fix-60">
                      <ul class="row" style="justify-content: flex-start;">
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-thun-nam">Áo Thun Nam</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-so-mi-nam">Áo Sơ Mi Nam</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-len-nam">Áo Len Nam</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-khoac-nam">Áo Khoác Nam</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/quan-short-nam">Quần Short Nam</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/quan-jean-nam">Quần Jeans Nam</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/quan-tay-nam">Quần Tây Nam</a>
                            
                          </li>
                        </div>
                          
                        
                      </ul>
                    </div>
                    <div class="big-image-header col md-fix-20">
                        <a href=""><img src="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" data-lazyload="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" alt="Sản phẩm" class="img-responsive center-block"></a>
                    </div>
                  </div>
                
              </li>
              
            
            
            
              <li class="lvl1 sidebar-menu-item has-mega">
                <a class="pdlr-16 pdtb-8 color-white" href="/categories/do-nu">NỮ <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                
                  <div class="row mega-content">
                    <div class="col md-fix-20">
                      <ul class="row" style="justify-content: space-around;">
                         <li class="sidebar-menu-item " style="display: flex; flex-direction: column;">
                           
                          </li>
                      </ul>
                    </div>
                    <div class="col md-fix-60">
                      <ul class="row" style="justify-content: flex-start;">
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-thun-nu">Áo Thun Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-so-mi-nu">Áo Sơ Mi Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-kieu">Áo Kiểu</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-len-nu">Áo Len Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-khoac-nu">Áo Khoác Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/quan-short-nu">Quần Short Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/quan-tay-nu">Quần Tây Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/quan-jean-nu">Quần Jeans Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/chan-vay">Chân Váy</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/yem">Yếm</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/vay-dam">Váy Đầm</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/set-bo">Set Bộ</a>
                            
                          </li>
                        </div>
                          
                        
                      </ul>
                    </div>
                    <div class="big-image-header col md-fix-20">
                        <a href=""><img src="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" data-lazyload="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" alt="Sản phẩm" class="img-responsive center-block"></a>
                    </div>
                  </div>
                
              </li>
              
            
            
            
              <li class="lvl1 sidebar-menu-item has-mega">
                <a class="pdlr-16 pdtb-8 color-white" href="/categories/tre-em">Trẻ em <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                
                  <div class="row mega-content">
                    <div class="col md-fix-20">
                      <ul class="row" style="justify-content: space-around;">
                         <li class="sidebar-menu-item " style="display: flex; flex-direction: column;">
                           
                          </li>
                      </ul>
                    </div>
                    <div class="col md-fix-60">
                      <ul class="row" style="justify-content: flex-start;">
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/be-trai">Bé Trai</a>
                            
                              <ul>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/ao-so-mi-be-trai" font-weight:"600">Áo sơ mi</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/ao-thun-be-trai" font-weight:"600">Áo thun</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/quan-dai-be-trai" font-weight:"600">Quần dài</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/quan-short-be-trai" font-weight:"600">Quần short</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/set-bo-be-trai" font-weight:"600">Set bộ</a>
                                  </li>
                                
                              </ul>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/be-gai">Bé Gái</a>
                            
                              <ul>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/so-mi-ao-kieu-be-gai" font-weight:"600">Sơ mi - Áo kiểu</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/ao-thun-be-gai" font-weight:"600">Áo thun</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/vay-dam-be-gai" font-weight:"600">Váy - Đầm</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/quan-dai-be-gai" font-weight:"600">Quần dài</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/quan-short-be-gai" font-weight:"600">Quần short</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/set-bo-be-gai" font-weight:"600">Set bộ</a>
                                  </li>
                                
                              </ul>
                            
                          </li>
                        </div>
                          
                        
                      </ul>
                    </div>
                    <div class="big-image-header col md-fix-20">
                        <a href=""><img src="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" data-lazyload="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" alt="Sản phẩm" class="img-responsive center-block"></a>
                    </div>
                  </div>
                
              </li>
              
            
            
            
              <li class="lvl1 sidebar-menu-item ">
                <a class="pdlr-16 pdtb-8 color-white" href="/categories/couple">Couple </a>
                
              </li>
              
            
            
            
              <li class="lvl1 sidebar-menu-item ">
                <a class="pdlr-16 pdtb-8 color-white" href="/categories/phu-kien">PHỤ KIỆN </a>
                
              </li>
              
            
            
            
              <li class="lvl1 sidebar-menu-item has-mega">
                <a class="pdlr-16 pdtb-8 color-white" href="https://anhtung.pancake.vn/pages/gioi-thieu-cong-ty">FM STYLE <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                
                  <div class="row mega-content">
                    <div class="col md-fix-20">
                      <ul class="row" style="justify-content: space-around;">
                         <li class="sidebar-menu-item " style="display: flex; flex-direction: column;">
                           
                          </li>
                      </ul>
                    </div>
                    <div class="col md-fix-60">
                      <ul class="row" style="justify-content: flex-start;">
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="https://anhtung.pancake.vn/pages/lich-su-hinh-thanh">Lịch Sử Hình Thành</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="https://fmstyle.com.vn/pages/vien-canh">Tầm Nhìn</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="https://fmstyle.com.vn/pages/su-menh">Sứ Mệnh</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="https://anhtung.pancake.vn/pages/van-hoa-cong-ty">Văn Hoá Công Ty</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="https://anhtung.pancake.vn/pages/danh-sach-dia-chi-cua-hang">Danh Sách Chi Nhánh</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="https://anhtung.pancake.vn/pages/ban-giam-doc">Ban Giám Đốc</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/pages/gia-tri-cot-loi">Giá Trị Cốt Lõi</a>
                            
                          </li>
                        </div>
                          
                        
                      </ul>
                    </div>
                    <div class="big-image-header col md-fix-20">
                        <a href=""><img src="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" data-lazyload="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" alt="Sản phẩm" class="img-responsive center-block"></a>
                    </div>
                  </div>
                
              </li>
              
            
            
            
              <li class="lvl1 sidebar-menu-item has-mega">
                <a class="pdlr-16 pdtb-8 color-white" href="/blog">TIN TỨC <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                
                  <div class="row mega-content">
                    <div class="col md-fix-20">
                      <ul class="row" style="justify-content: space-around;">
                         <li class="sidebar-menu-item " style="display: flex; flex-direction: column;">
                           
                          </li>
                      </ul>
                    </div>
                    <div class="col md-fix-60">
                      <ul class="row" style="justify-content: flex-start;">
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/blog/tips-thoi-trang">TIPS THỜI TRANG</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/blog/chuong-trinh-sale">CHƯƠNG TRÌNH SALE</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/blog/goc-gop-y">GÓC GÓP Ý</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/blog/tuyen-dung">TUYỂN DỤNG</a>
                            
                          </li>
                        </div>
                          
                        
                      </ul>
                    </div>
                    <div class="big-image-header col md-fix-20">
                        <a href=""><img src="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" data-lazyload="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" alt="Sản phẩm" class="img-responsive center-block"></a>
                    </div>
                  </div>
                
              </li>
              
            
          
        
          
        
          
        
          
        
        </ul>
        </nav>
        <div class="from-right is-flex hidden-md">
          <div class="cart-box">
            <a href="/cart">
              <div class="cart-box-btn pos-relative"><i class="fa fa-cart-arrow-down pos-relative"></i><span class="pos-absolute">0</span></div>
            </a>
          </div>
        </div>
			</div>
    </div>
  </div>
</header>
<nav class="pdtb-6 hidden-md hidden-lg-up">
  <div class="wrapper">
    <div class="container">
      <ul class="nav">
        
        
          
            <li class="lvl1 sidebar-menu-item ">
              <a class="pdlr-16 pdtb-8" href="https://anhtung.pancake.vn/">TRANG CHỦ </a>
              
            </li>
          
            <li class="lvl1 sidebar-menu-item has-mega">
              <a class="pdlr-16 pdtb-8" href="/categories/do-nam">NAM <i class="fa fa-angle-right" aria-hidden="true"></i></a>
              
                <div class="row mega-content">
                    <div class="col md-fix-20">
                      <ul class="row" style="justify-content: space-around;">
                         <li class="sidebar-menu-item " style="display: flex; flex-direction: column;">
                           
                          </li>
                      </ul>
                    </div>
                    <div class="col md-fix-60">
                      <ul class="row" style="justify-content: flex-start;">
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-thun-nam">Áo Thun Nam</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-so-mi-nam">Áo Sơ Mi Nam</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-len-nam">Áo Len Nam</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-khoac-nam">Áo Khoác Nam</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/quan-short-nam">Quần Short Nam</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/quan-jean-nam">Quần Jeans Nam</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/quan-tay-nam">Quần Tây Nam</a>
                            
                          </li>
                        </div>
                          
                        
                      </ul>
                    </div>
                    <div class="big-image-header col md-fix-20">
                        <a href=""><img src="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" data-lazyload="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" alt="Sản phẩm" class="img-responsive center-block"></a>
                    </div>
                  </div>
              
            </li>
          
            <li class="lvl1 sidebar-menu-item has-mega">
              <a class="pdlr-16 pdtb-8" href="/categories/do-nu">NỮ <i class="fa fa-angle-right" aria-hidden="true"></i></a>
              
                <div class="row mega-content">
                    <div class="col md-fix-20">
                      <ul class="row" style="justify-content: space-around;">
                         <li class="sidebar-menu-item " style="display: flex; flex-direction: column;">
                           
                          </li>
                      </ul>
                    </div>
                    <div class="col md-fix-60">
                      <ul class="row" style="justify-content: flex-start;">
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-thun-nu">Áo Thun Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-so-mi-nu">Áo Sơ Mi Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-kieu">Áo Kiểu</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-len-nu">Áo Len Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/ao-khoac-nu">Áo Khoác Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/quan-short-nu">Quần Short Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/quan-tay-nu">Quần Tây Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/quan-jean-nu">Quần Jeans Nữ</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/chan-vay">Chân Váy</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/yem">Yếm</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/vay-dam">Váy Đầm</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/set-bo">Set Bộ</a>
                            
                          </li>
                        </div>
                          
                        
                      </ul>
                    </div>
                    <div class="big-image-header col md-fix-20">
                        <a href=""><img src="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" data-lazyload="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" alt="Sản phẩm" class="img-responsive center-block"></a>
                    </div>
                  </div>
              
            </li>
          
            <li class="lvl1 sidebar-menu-item has-mega">
              <a class="pdlr-16 pdtb-8" href="/categories/tre-em">Trẻ em <i class="fa fa-angle-right" aria-hidden="true"></i></a>
              
                <div class="row mega-content">
                    <div class="col md-fix-20">
                      <ul class="row" style="justify-content: space-around;">
                         <li class="sidebar-menu-item " style="display: flex; flex-direction: column;">
                           
                          </li>
                      </ul>
                    </div>
                    <div class="col md-fix-60">
                      <ul class="row" style="justify-content: flex-start;">
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/be-trai">Bé Trai</a>
                            
                              <ul>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/ao-so-mi-be-trai" font-weight:"600">Áo sơ mi</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/ao-thun-be-trai" font-weight:"600">Áo thun</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/quan-dai-be-trai" font-weight:"600">Quần dài</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/quan-short-be-trai" font-weight:"600">Quần short</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/set-bo-be-trai" font-weight:"600">Set bộ</a>
                                  </li>
                                
                              </ul>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/categories/be-gai">Bé Gái</a>
                            
                              <ul>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/so-mi-ao-kieu-be-gai" font-weight:"600">Sơ mi - Áo kiểu</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/ao-thun-be-gai" font-weight:"600">Áo thun</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/vay-dam-be-gai" font-weight:"600">Váy - Đầm</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/quan-dai-be-gai" font-weight:"600">Quần dài</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/quan-short-be-gai" font-weight:"600">Quần short</a>
                                  </li>
                                
                                  <li class="sidebar-menu-item" font-weight:"600">
                                    <a href="/categories/set-bo-be-gai" font-weight:"600">Set bộ</a>
                                  </li>
                                
                              </ul>
                            
                          </li>
                        </div>
                          
                        
                      </ul>
                    </div>
                    <div class="big-image-header col md-fix-20">
                        <a href=""><img src="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" data-lazyload="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" alt="Sản phẩm" class="img-responsive center-block"></a>
                    </div>
                  </div>
              
            </li>
          
            <li class="lvl1 sidebar-menu-item ">
              <a class="pdlr-16 pdtb-8" href="/categories/couple">Couple </a>
              
            </li>
          
            <li class="lvl1 sidebar-menu-item ">
              <a class="pdlr-16 pdtb-8" href="/categories/phu-kien">PHỤ KIỆN </a>
              
            </li>
          
            <li class="lvl1 sidebar-menu-item has-mega">
              <a class="pdlr-16 pdtb-8" href="https://anhtung.pancake.vn/pages/gioi-thieu-cong-ty">FM STYLE <i class="fa fa-angle-right" aria-hidden="true"></i></a>
              
                <div class="row mega-content">
                    <div class="col md-fix-20">
                      <ul class="row" style="justify-content: space-around;">
                         <li class="sidebar-menu-item " style="display: flex; flex-direction: column;">
                           
                          </li>
                      </ul>
                    </div>
                    <div class="col md-fix-60">
                      <ul class="row" style="justify-content: flex-start;">
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="https://anhtung.pancake.vn/pages/lich-su-hinh-thanh">Lịch Sử Hình Thành</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="https://fmstyle.com.vn/pages/vien-canh">Tầm Nhìn</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="https://fmstyle.com.vn/pages/su-menh">Sứ Mệnh</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="https://anhtung.pancake.vn/pages/van-hoa-cong-ty">Văn Hoá Công Ty</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="https://anhtung.pancake.vn/pages/danh-sach-dia-chi-cua-hang">Danh Sách Chi Nhánh</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="https://anhtung.pancake.vn/pages/ban-giam-doc">Ban Giám Đốc</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/pages/gia-tri-cot-loi">Giá Trị Cốt Lõi</a>
                            
                          </li>
                        </div>
                          
                        
                      </ul>
                    </div>
                    <div class="big-image-header col md-fix-20">
                        <a href=""><img src="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" data-lazyload="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" alt="Sản phẩm" class="img-responsive center-block"></a>
                    </div>
                  </div>
              
            </li>
          
            <li class="lvl1 sidebar-menu-item has-mega">
              <a class="pdlr-16 pdtb-8" href="/blog">TIN TỨC <i class="fa fa-angle-right" aria-hidden="true"></i></a>
              
                <div class="row mega-content">
                    <div class="col md-fix-20">
                      <ul class="row" style="justify-content: space-around;">
                         <li class="sidebar-menu-item " style="display: flex; flex-direction: column;">
                           
                          </li>
                      </ul>
                    </div>
                    <div class="col md-fix-60">
                      <ul class="row" style="justify-content: flex-start;">
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/blog/tips-thoi-trang">TIPS THỜI TRANG</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/blog/chuong-trinh-sale">CHƯƠNG TRÌNH SALE</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/blog/goc-gop-y">GÓC GÓP Ý</a>
                            
                          </li>
                        </div>
                          
                        
                        
                        <div class="col lg-8 ">
                          <li class="sidebar-menu-item">
                            <a href="/blog/tuyen-dung">TUYỂN DỤNG</a>
                            
                          </li>
                        </div>
                          
                        
                      </ul>
                    </div>
                    <div class="big-image-header col md-fix-20">
                        <a href=""><img src="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" data-lazyload="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" alt="Sản phẩm" class="img-responsive center-block"></a>
                    </div>
                  </div>
              
            </li>
          
        
      
        
      
        
      
        
      
      </ul>
    </div>
  </div>
</nav>
<!-- End header -->
<div class="backdrop hidden-md-up" id="backdrop" style="display: none">
</div>
<div class="close-sidebar">
  <i class="fa fa-times" aria-hidden="true" style="font-size: 19px"></i>
</div>
<div class="sidebar hidden-md-up" id="sidebar" style="transform: translateX(-250px); height: 100%">
  <div class="sidebar-container data-lvl" id="sidebar-container">
    <div class="sidebar-header is-none hidden-md-up pd-14 ali-center">
    <div class="account-ava mgr-20">
      <img src="https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png" alt="Ant Green">
    </div>
    <div class="is-flex is-flex--column ">
      <div class="color-white fs-14 uppercase hello">
        <a href="/customer/login" class="color-white">Đăng nhập</a>
      </div>
      <div class="color-white fs-14 name-login">
        Nhận nhiều ưu đãi hơn
      </div>
      <div class="color-white fs-14 un-name-login">
        
      </div>
    </div>
  </div>
    <div class="sidebar-content pdl-10 fw-600" id="sidebar">
     <div class="log-in-mobile is-none"><a href="/customer/login" class="fs-14">Đăng nhập</a></div>
     <div class="log-in-mobile is-none"><a href="/customer/register" class="fs-14">Đăng kí</a></div>
     <div class="log-out-mobile is-none"><a href="/customer/logout" class="fs-14"><i class="fa fa-sign-out"></i> Thoát</a></div>
    
      <ul id="sidebar-menu">
        
          
            
            
              
                <li class="sidebar-menu-item " data-target="https://anhtung.pancake.vn/">
                  <a href="https://anhtung.pancake.vn/">TRANG CHỦ</a>
                  
                </li>
              
              
            
            
              
                <li class="sidebar-menu-item has-mega" data-target="/categories/do-nam">
                  <a href="/categories/do-nam">NAM</a>
                  
                    <span class="open-node" data-target="/categories/do-nam" data-title="NAM">
                      <i class="fa fa-caret-right" aria-hidden="true"></i>
                    </span>
                  
                </li>
              
              
            
            
              
                <li class="sidebar-menu-item has-mega" data-target="/categories/do-nu">
                  <a href="/categories/do-nu">NỮ</a>
                  
                    <span class="open-node" data-target="/categories/do-nu" data-title="NỮ">
                      <i class="fa fa-caret-right" aria-hidden="true"></i>
                    </span>
                  
                </li>
              
              
            
            
              
                <li class="sidebar-menu-item has-mega" data-target="/categories/tre-em">
                  <a href="/categories/tre-em">Trẻ em</a>
                  
                    <span class="open-node" data-target="/categories/tre-em" data-title="Trẻ em">
                      <i class="fa fa-caret-right" aria-hidden="true"></i>
                    </span>
                  
                </li>
              
              
            
            
              
                <li class="sidebar-menu-item " data-target="/categories/couple">
                  <a href="/categories/couple">Couple</a>
                  
                </li>
              
              
            
            
              
                <li class="sidebar-menu-item " data-target="/categories/phu-kien">
                  <a href="/categories/phu-kien">PHỤ KIỆN</a>
                  
                </li>
              
              
            
            
              
                <li class="sidebar-menu-item has-mega" data-target="https://anhtung.pancake.vn/pages/gioi-thieu-cong-ty">
                  <a href="https://anhtung.pancake.vn/pages/gioi-thieu-cong-ty">FM STYLE</a>
                  
                    <span class="open-node" data-target="https://anhtung.pancake.vn/pages/gioi-thieu-cong-ty" data-title="FM STYLE">
                      <i class="fa fa-caret-right" aria-hidden="true"></i>
                    </span>
                  
                </li>
              
              
            
            
              
                <li class="sidebar-menu-item has-mega" data-target="/blog">
                  <a href="/blog">TIN TỨC</a>
                  
                    <span class="open-node" data-target="/blog" data-title="TIN TỨC">
                      <i class="fa fa-caret-right" aria-hidden="true"></i>
                    </span>
                  
                </li>
              
              
            
          
        
          
        
          
        
          
        
        <li class="sidebar-menu-item hidden-md-up ">
          <a href="/customer/register" style="color: #78ce64">Đăng ký</a>
        </li>
        <li class="sidebar-menu-item hidden-md-up ">
          <a href="/customer/login" style="color: #78ce64">Đăng nhập</a>
        </li>
        <li class="sidebar-menu-item hidden-md-up ">
          <a href="/customer/account" style="color: #78ce64">Tài khoản</a>
        </li>
      </ul>
    </div>
    <div class="filters-mobile" id="filters-mobile"></div>
  </div>
  <script type="application/json" id="a">[{"allow_deleted":false,"content":[{"children":[],"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//trang-chu","productQuantity":0,"title":"TRANG CHỦ","titleAttribute":"trang-chu","type":4,"url":"https://anhtung.pancake.vn/"}},{"children":[{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nam/ao-thun-nam","productQuantity":0,"title":"Áo Thun Nam","titleAttribute":"ao-thun-nam","type":4,"url":"/categories/ao-thun-nam"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nam/ao-so-mi-nam","productQuantity":0,"title":"Áo Sơ Mi Nam","titleAttribute":"ao-so-mi-nam","type":4,"url":"/categories/ao-so-mi-nam"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nam/ao-len-nam","productQuantity":0,"title":"Áo Len Nam","titleAttribute":"ao-len-nam","type":4,"url":"/categories/ao-len-nam"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nam/ao-khoac-nam","productQuantity":0,"title":"Áo Khoác Nam","titleAttribute":"ao-khoac-nam","type":4,"url":"/categories/ao-khoac-nam"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nam/quan-short-nam","productQuantity":0,"title":"Quần Short Nam","titleAttribute":"quan-short-nam","type":4,"url":"/categories/quan-short-nam"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nam/quan-jean-nam","productQuantity":0,"title":"Quần Jeans Nam","titleAttribute":"quan-jean-nam","type":4,"url":"/categories/quan-jean-nam"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nam/quan-tay-nam","productQuantity":0,"title":"Quần Tây Nam","titleAttribute":"quan-tay-nam","type":4,"url":"/categories/quan-tay-nam"}}],"content":[{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nam/ao-thun-nam","productQuantity":0,"title":"Áo Thun Nam","titleAttribute":"ao-thun-nam","type":4,"url":"/categories/ao-thun-nam"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nam/ao-so-mi-nam","productQuantity":0,"title":"Áo Sơ Mi Nam","titleAttribute":"ao-so-mi-nam","type":4,"url":"/categories/ao-so-mi-nam"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nam/ao-len-nam","productQuantity":0,"title":"Áo Len Nam","titleAttribute":"ao-len-nam","type":4,"url":"/categories/ao-len-nam"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nam/ao-khoac-nam","productQuantity":0,"title":"Áo Khoác Nam","titleAttribute":"ao-khoac-nam","type":4,"url":"/categories/ao-khoac-nam"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nam/quan-short-nam","productQuantity":0,"title":"Quần Short Nam","titleAttribute":"quan-short-nam","type":4,"url":"/categories/quan-short-nam"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nam/quan-jean-nam","productQuantity":0,"title":"Quần Jeans Nam","titleAttribute":"quan-jean-nam","type":4,"url":"/categories/quan-jean-nam"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nam/quan-tay-nam","productQuantity":0,"title":"Quần Tây Nam","titleAttribute":"quan-tay-nam","type":4,"url":"/categories/quan-tay-nam"}}],"value":{"css":"","description":"","expanded":false,"icon":"","image":"https://statics.pancake.vn/web-media/f4/12/fd/ed/f49a858524de3f7191147e2301bd83c51efff494baf0d56b4801005e.jpg","linkRelationship":"","path":"/categories//do-nam","productQuantity":1,"title":"NAM","titleAttribute":"do-nam","type":4,"url":"/categories/do-nam"}},{"children":[{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nu/ao-thun-nu","productQuantity":0,"title":"Áo Thun Nữ","titleAttribute":"ao-thun-nu","type":4,"url":"/categories/ao-thun-nu"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nu/ao-so-mi-nu","productQuantity":0,"title":"Áo Sơ Mi Nữ","titleAttribute":"ao-so-mi-nu","type":4,"url":"/categories/ao-so-mi-nu"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//ao-kieu","productQuantity":0,"title":"Áo Kiểu","titleAttribute":"ao-kieu","type":4,"url":"/categories/ao-kieu"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nu/ao-len-nu","productQuantity":0,"title":"Áo Len Nữ","titleAttribute":"ao-len-nu","type":4,"url":"/categories/ao-len-nu"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nu/ao-khoac-nu","productQuantity":0,"title":"Áo Khoác Nữ","titleAttribute":"ao-khoac-nu","type":4,"url":"/categories/ao-khoac-nu"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nu/quan-short-nu","productQuantity":0,"title":"Quần Short Nữ","titleAttribute":"quan-short-nu","type":4,"url":"/categories/quan-short-nu"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//quan-tay-nu","productQuantity":0,"title":"Quần Tây Nữ","titleAttribute":"quan-tay-nu","type":4,"url":"/categories/quan-tay-nu"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nu/quan-jean-nu","productQuantity":0,"title":"Quần Jeans Nữ","titleAttribute":"quan-jean-nu","type":4,"url":"/categories/quan-jean-nu"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nu/chan-vay","productQuantity":0,"title":"Chân Váy","titleAttribute":"chan-vay","type":4,"url":"/categories/chan-vay"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//yem","productQuantity":0,"title":"Yếm","titleAttribute":"yem","type":4,"url":"/categories/yem"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nu/vay-dam","productQuantity":0,"title":"Váy Đầm","titleAttribute":"vay-dam","type":4,"url":"/categories/vay-dam"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//set-bo","productQuantity":0,"title":"Set Bộ","titleAttribute":"set-bo","type":4,"url":"/categories/set-bo"}}],"content":[{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nu/ao-thun-nu","productQuantity":0,"title":"Áo Thun Nữ","titleAttribute":"ao-thun-nu","type":4,"url":"/categories/ao-thun-nu"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nu/ao-so-mi-nu","productQuantity":0,"title":"Áo Sơ Mi Nữ","titleAttribute":"ao-so-mi-nu","type":4,"url":"/categories/ao-so-mi-nu"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//ao-kieu","productQuantity":0,"title":"Áo Kiểu","titleAttribute":"ao-kieu","type":4,"url":"/categories/ao-kieu"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nu/ao-len-nu","productQuantity":0,"title":"Áo Len Nữ","titleAttribute":"ao-len-nu","type":4,"url":"/categories/ao-len-nu"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nu/ao-khoac-nu","productQuantity":0,"title":"Áo Khoác Nữ","titleAttribute":"ao-khoac-nu","type":4,"url":"/categories/ao-khoac-nu"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nu/quan-short-nu","productQuantity":0,"title":"Quần Short Nữ","titleAttribute":"quan-short-nu","type":4,"url":"/categories/quan-short-nu"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//quan-tay-nu","productQuantity":0,"title":"Quần Tây Nữ","titleAttribute":"quan-tay-nu","type":4,"url":"/categories/quan-tay-nu"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nu/quan-jean-nu","productQuantity":0,"title":"Quần Jeans Nữ","titleAttribute":"quan-jean-nu","type":4,"url":"/categories/quan-jean-nu"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nu/chan-vay","productQuantity":0,"title":"Chân Váy","titleAttribute":"chan-vay","type":4,"url":"/categories/chan-vay"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//yem","productQuantity":0,"title":"Yếm","titleAttribute":"yem","type":4,"url":"/categories/yem"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//do-nu/vay-dam","productQuantity":0,"title":"Váy Đầm","titleAttribute":"vay-dam","type":4,"url":"/categories/vay-dam"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//set-bo","productQuantity":0,"title":"Set Bộ","titleAttribute":"set-bo","type":4,"url":"/categories/set-bo"}}],"value":{"css":"","description":"","expanded":false,"icon":"","image":"https://statics.pancake.vn/web-media/0d/73/23/48/118d447fd60829b3fa6c7b9206b37bccd9db020ac1e69950888a5873.jpg","linkRelationship":"","path":"/categories//do-nu","productQuantity":0,"title":"NỮ","titleAttribute":"do-nu","type":4,"url":"/categories/do-nu"}},{"children":[{"children":[{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//tre-em/be-trai/ao-so-mi-be-trai","productQuantity":0,"title":"Áo sơ mi","titleAttribute":"ao-so-mi-be-trai","type":4,"url":"/categories/ao-so-mi-be-trai"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//tre-em/be-trai/ao-thun-be-trai","productQuantity":0,"title":"Áo thun","titleAttribute":"ao-thun-be-trai","type":4,"url":"/categories/ao-thun-be-trai"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//tre-em/be-trai/quan-dai-be-trai","productQuantity":0,"title":"Quần dài","titleAttribute":"quan-dai-be-trai","type":4,"url":"/categories/quan-dai-be-trai"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//tre-em/be-trai/quan-short-be-trai","productQuantity":0,"title":"Quần short","titleAttribute":"quan-short-be-trai","type":4,"url":"/categories/quan-short-be-trai"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//tre-em/be-trai/set-bo-be-trai","productQuantity":0,"title":"Set bộ","titleAttribute":"set-bo-be-trai","type":4,"url":"/categories/set-bo-be-trai"}}],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//tre-em/be-trai","productQuantity":0,"title":"Bé Trai","titleAttribute":"be-trai","type":4,"url":"/categories/be-trai"}},{"children":[{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//so-mi-ao-kieu-be-gai","productQuantity":0,"title":"Sơ mi - Áo kiểu","titleAttribute":"so-mi-ao-kieu-be-gai","type":4,"url":"/categories/so-mi-ao-kieu-be-gai"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//ao-thun-be-gai","productQuantity":0,"title":"Áo thun","titleAttribute":"ao-thun-be-gai","type":4,"url":"/categories/ao-thun-be-gai"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//vay-dam-be-gai","productQuantity":0,"title":"Váy - Đầm","titleAttribute":"vay-dam-be-gai","type":4,"url":"/categories/vay-dam-be-gai"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//quan-dai-be-gai","productQuantity":0,"title":"Quần dài","titleAttribute":"quan-dai-be-gai","type":4,"url":"/categories/quan-dai-be-gai"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//quan-short-be-gai","productQuantity":0,"title":"Quần short","titleAttribute":"quan-short-be-gai","type":4,"url":"/categories/quan-short-be-gai"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//set-bo-be-gai","productQuantity":0,"title":"Set bộ","titleAttribute":"set-bo-be-gai","type":4,"url":"/categories/set-bo-be-gai"}}],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//be-gai","productQuantity":0,"title":"Bé Gái","titleAttribute":"be-gai","type":4,"url":"/categories/be-gai"}}],"content":[{"children":[{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//tre-em/be-trai/ao-so-mi-be-trai","productQuantity":0,"title":"Áo sơ mi","titleAttribute":"ao-so-mi-be-trai","type":4,"url":"/categories/ao-so-mi-be-trai"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//tre-em/be-trai/ao-thun-be-trai","productQuantity":0,"title":"Áo thun","titleAttribute":"ao-thun-be-trai","type":4,"url":"/categories/ao-thun-be-trai"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//tre-em/be-trai/quan-dai-be-trai","productQuantity":0,"title":"Quần dài","titleAttribute":"quan-dai-be-trai","type":4,"url":"/categories/quan-dai-be-trai"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//tre-em/be-trai/quan-short-be-trai","productQuantity":0,"title":"Quần short","titleAttribute":"quan-short-be-trai","type":4,"url":"/categories/quan-short-be-trai"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//tre-em/be-trai/set-bo-be-trai","productQuantity":0,"title":"Set bộ","titleAttribute":"set-bo-be-trai","type":4,"url":"/categories/set-bo-be-trai"}}],"content":[{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//tre-em/be-trai/ao-so-mi-be-trai","productQuantity":0,"title":"Áo sơ mi","titleAttribute":"ao-so-mi-be-trai","type":4,"url":"/categories/ao-so-mi-be-trai"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//tre-em/be-trai/ao-thun-be-trai","productQuantity":0,"title":"Áo thun","titleAttribute":"ao-thun-be-trai","type":4,"url":"/categories/ao-thun-be-trai"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//tre-em/be-trai/quan-dai-be-trai","productQuantity":0,"title":"Quần dài","titleAttribute":"quan-dai-be-trai","type":4,"url":"/categories/quan-dai-be-trai"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//tre-em/be-trai/quan-short-be-trai","productQuantity":0,"title":"Quần short","titleAttribute":"quan-short-be-trai","type":4,"url":"/categories/quan-short-be-trai"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//tre-em/be-trai/set-bo-be-trai","productQuantity":0,"title":"Set bộ","titleAttribute":"set-bo-be-trai","type":4,"url":"/categories/set-bo-be-trai"}}],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//tre-em/be-trai","productQuantity":0,"title":"Bé Trai","titleAttribute":"be-trai","type":4,"url":"/categories/be-trai"}},{"children":[{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//so-mi-ao-kieu-be-gai","productQuantity":0,"title":"Sơ mi - Áo kiểu","titleAttribute":"so-mi-ao-kieu-be-gai","type":4,"url":"/categories/so-mi-ao-kieu-be-gai"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//ao-thun-be-gai","productQuantity":0,"title":"Áo thun","titleAttribute":"ao-thun-be-gai","type":4,"url":"/categories/ao-thun-be-gai"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//vay-dam-be-gai","productQuantity":0,"title":"Váy - Đầm","titleAttribute":"vay-dam-be-gai","type":4,"url":"/categories/vay-dam-be-gai"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//quan-dai-be-gai","productQuantity":0,"title":"Quần dài","titleAttribute":"quan-dai-be-gai","type":4,"url":"/categories/quan-dai-be-gai"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//quan-short-be-gai","productQuantity":0,"title":"Quần short","titleAttribute":"quan-short-be-gai","type":4,"url":"/categories/quan-short-be-gai"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//set-bo-be-gai","productQuantity":0,"title":"Set bộ","titleAttribute":"set-bo-be-gai","type":4,"url":"/categories/set-bo-be-gai"}}],"content":[{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//so-mi-ao-kieu-be-gai","productQuantity":0,"title":"Sơ mi - Áo kiểu","titleAttribute":"so-mi-ao-kieu-be-gai","type":4,"url":"/categories/so-mi-ao-kieu-be-gai"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//ao-thun-be-gai","productQuantity":0,"title":"Áo thun","titleAttribute":"ao-thun-be-gai","type":4,"url":"/categories/ao-thun-be-gai"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//vay-dam-be-gai","productQuantity":0,"title":"Váy - Đầm","titleAttribute":"vay-dam-be-gai","type":4,"url":"/categories/vay-dam-be-gai"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//quan-dai-be-gai","productQuantity":0,"title":"Quần dài","titleAttribute":"quan-dai-be-gai","type":4,"url":"/categories/quan-dai-be-gai"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//quan-short-be-gai","productQuantity":0,"title":"Quần short","titleAttribute":"quan-short-be-gai","type":4,"url":"/categories/quan-short-be-gai"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//set-bo-be-gai","productQuantity":0,"title":"Set bộ","titleAttribute":"set-bo-be-gai","type":4,"url":"/categories/set-bo-be-gai"}}],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//be-gai","productQuantity":0,"title":"Bé Gái","titleAttribute":"be-gai","type":4,"url":"/categories/be-gai"}}],"value":{"css":"","description":"","expanded":false,"icon":"","image":"","linkRelationship":"","path":"/categories//tre-em","productQuantity":0,"title":"Trẻ em","titleAttribute":"tre-em","type":4,"url":"/categories/tre-em"}},{"content":[],"value":{"css":"","description":"","icon":"","image":"","linkRelationship":"","path":"/categories//couple","productQuantity":0,"title":"Couple","titleAttribute":"couple","type":4,"url":"/categories/couple"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//phu-kien","productQuantity":0,"title":"PHỤ KIỆN","titleAttribute":"phu-kien","type":4,"url":"/categories/phu-kien"}},{"children":[{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//about-us/lich-su-hinh-thanh","productQuantity":0,"title":"Lịch Sử Hình Thành","titleAttribute":"lich-su-hinh-thanh","type":4,"url":"https://anhtung.pancake.vn/pages/lich-su-hinh-thanh"}},{"hidden":true,"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//about-us/tam-nhin","productQuantity":0,"title":"Tầm Nhìn","titleAttribute":"tam-nhin","type":4,"url":"https://fmstyle.com.vn/pages/vien-canh"}},{"hidden":true,"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//about-us/su-menh","productQuantity":0,"title":"Sứ Mệnh","titleAttribute":"su-menh","type":4,"url":"https://fmstyle.com.vn/pages/su-menh"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//about-us/van-hoa-cong-ty","productQuantity":0,"title":"Văn Hoá Công Ty","titleAttribute":"van-hoa-cong-ty","type":4,"url":"https://anhtung.pancake.vn/pages/van-hoa-cong-ty"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//about-us/danh-sach-chi-nhanh","productQuantity":0,"title":"Danh Sách Chi Nhánh","titleAttribute":"danh-sach-chi-nhanh","type":4,"url":"https://anhtung.pancake.vn/pages/danh-sach-dia-chi-cua-hang"}},{"hidden":true,"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//about-us/ban-giam-doc","productQuantity":0,"title":"Ban Giám Đốc","titleAttribute":"ban-giam-doc","type":4,"url":"https://anhtung.pancake.vn/pages/ban-giam-doc"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"","productQuantity":0,"title":"Giá Trị Cốt Lõi","titleAttribute":"","type":1,"url":"/pages/gia-tri-cot-loi"}}],"content":[{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//about-us/lich-su-hinh-thanh","productQuantity":0,"title":"Lịch Sử Hình Thành","titleAttribute":"lich-su-hinh-thanh","type":4,"url":"https://anhtung.pancake.vn/pages/lich-su-hinh-thanh"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//about-us/van-hoa-cong-ty","productQuantity":0,"title":"Văn Hoá Công Ty","titleAttribute":"van-hoa-cong-ty","type":4,"url":"https://anhtung.pancake.vn/pages/van-hoa-cong-ty"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"/categories//about-us/danh-sach-chi-nhanh","productQuantity":0,"title":"Danh Sách Chi Nhánh","titleAttribute":"danh-sach-chi-nhanh","type":4,"url":"https://anhtung.pancake.vn/pages/danh-sach-dia-chi-cua-hang"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"","productQuantity":0,"title":"Giá Trị Cốt Lõi","titleAttribute":"","type":1,"url":"/pages/gia-tri-cot-loi"}}],"value":{"css":"","description":"<p>C&ocirc;ng ty th&agrave;nh lập abc xyu</p>\n<p>được anc năm</p>","expanded":true,"icon":"","image":"https://statics.pancake.vn/web-media/b1/60/53/c1/302cdc7b4f55efa23b5aa99b071f97b60431b8ed3db08ae721c49cfd.jpg","linkRelationship":"","path":"/categories//about-us","productQuantity":0,"title":"FM STYLE","titleAttribute":"about-us","type":4,"url":"https://anhtung.pancake.vn/pages/gioi-thieu-cong-ty"}},{"children":[{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"","productQuantity":0,"title":"TIPS THỜI TRANG","titleAttribute":"","type":5,"url":"/blog/tips-thoi-trang"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"","productQuantity":0,"title":"CHƯƠNG TRÌNH SALE","titleAttribute":"","type":5,"url":"/blog/chuong-trinh-sale"}},{"children":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"","productQuantity":0,"title":"GÓC GÓP Ý","titleAttribute":"","type":5,"url":"/blog/goc-gop-y"}},{"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"","productQuantity":0,"title":"TUYỂN DỤNG","titleAttribute":"","type":5,"url":"/blog/tuyen-dung"}}],"content":[{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"","productQuantity":0,"title":"TIPS THỜI TRANG","titleAttribute":"","type":5,"url":"/blog/tips-thoi-trang"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"","productQuantity":0,"title":"CHƯƠNG TRÌNH SALE","titleAttribute":"","type":5,"url":"/blog/chuong-trinh-sale"}},{"children":[],"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"","productQuantity":0,"title":"GÓC GÓP Ý","titleAttribute":"","type":5,"url":"/blog/goc-gop-y"}},{"content":[],"value":{"css":"","description":"","expanded":true,"icon":"","image":"","linkRelationship":"","path":"","productQuantity":0,"title":"TUYỂN DỤNG","titleAttribute":"","type":5,"url":"/blog/tuyen-dung"}}],"value":{"css":"","description":"","expanded":true,"icon":"","image":"https://statics.pancake.vn/web-media/17/f9/46/41/4b5cef79ba9ea2bdf64ce6197db380204b73525af00e4b8017667bd1.png","linkRelationship":"","path":"/categories//tin-tuc","productQuantity":0,"title":"TIN TỨC","titleAttribute":"tin-tuc","type":4,"url":"/blog"}}],"name":"header"},{"allow_deleted":false,"content":[],"name":"footer"},{"allow_deleted":false,"content":[{"content":[],"value":{"css":"","description":"","icon":"","image":"","linkRelationship":"","path":"/categories//huong-dan-mua-hang","productQuantity":0,"title":"Hướng Dẫn Mua Hàng","titleAttribute":"huong-dan-mua-hang","type":4,"url":"/categories/huong-dan-mua-hang"}}],"name":"aside"},{"allow_deleted":true,"content":[],"name":"GÓC PHẢI "}]</script>
  
    
      
        
      
        
          <div class="data-lvl" data-lvl="1" data-type="nested-content" id="/categories/do-nam">
            <div class="prev-node pos-relative pd-10">
              <span class="prev-node-btn"><i class="fa fa-caret-left" aria-hidden="true"></i></span>
              <div class="prev-node-title" id="node-title"></div>
            </div>
            <ul>
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/ao-thun-nam">Áo Thun Nam</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/ao-so-mi-nam">Áo Sơ Mi Nam</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/ao-len-nam">Áo Len Nam</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/ao-khoac-nam">Áo Khoác Nam</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/quan-short-nam">Quần Short Nam</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/quan-jean-nam">Quần Jeans Nam</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/quan-tay-nam">Quần Tây Nam</a>
                  
                </li>
                
                
              
            </ul>
          </div>
        
      
        
          <div class="data-lvl" data-lvl="1" data-type="nested-content" id="/categories/do-nu">
            <div class="prev-node pos-relative pd-10">
              <span class="prev-node-btn"><i class="fa fa-caret-left" aria-hidden="true"></i></span>
              <div class="prev-node-title" id="node-title"></div>
            </div>
            <ul>
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/ao-thun-nu">Áo Thun Nữ</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/ao-so-mi-nu">Áo Sơ Mi Nữ</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/ao-kieu">Áo Kiểu</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/ao-len-nu">Áo Len Nữ</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/ao-khoac-nu">Áo Khoác Nữ</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/quan-short-nu">Quần Short Nữ</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/quan-tay-nu">Quần Tây Nữ</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/quan-jean-nu">Quần Jeans Nữ</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/chan-vay">Chân Váy</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/yem">Yếm</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/vay-dam">Váy Đầm</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/set-bo">Set Bộ</a>
                  
                </li>
                
                
              
            </ul>
          </div>
        
      
        
          <div class="data-lvl" data-lvl="1" data-type="nested-content" id="/categories/tre-em">
            <div class="prev-node pos-relative pd-10">
              <span class="prev-node-btn"><i class="fa fa-caret-left" aria-hidden="true"></i></span>
              <div class="prev-node-title" id="node-title"></div>
            </div>
            <ul>
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/be-trai">Bé Trai</a>
                  
                    <span class="open-node" data-target="/categories/be-trai" data-title="Bé Trai">
                      <i class="fa fa-caret-right" aria-hidden="true"></i>
                    </span>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/categories/be-gai">Bé Gái</a>
                  
                    <span class="open-node" data-target="/categories/be-gai" data-title="Bé Gái">
                      <i class="fa fa-caret-right" aria-hidden="true"></i>
                    </span>
                  
                </li>
                
                
              
            </ul>
          </div>
        
      
        
      
        
      
        
          <div class="data-lvl" data-lvl="1" data-type="nested-content" id="https://anhtung.pancake.vn/pages/gioi-thieu-cong-ty">
            <div class="prev-node pos-relative pd-10">
              <span class="prev-node-btn"><i class="fa fa-caret-left" aria-hidden="true"></i></span>
              <div class="prev-node-title" id="node-title"></div>
            </div>
            <ul>
              
                
                <li class="sidebar-menu-item">
                  <a href="https://anhtung.pancake.vn/pages/lich-su-hinh-thanh">Lịch Sử Hình Thành</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="https://fmstyle.com.vn/pages/vien-canh">Tầm Nhìn</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="https://fmstyle.com.vn/pages/su-menh">Sứ Mệnh</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="https://anhtung.pancake.vn/pages/van-hoa-cong-ty">Văn Hoá Công Ty</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="https://anhtung.pancake.vn/pages/danh-sach-dia-chi-cua-hang">Danh Sách Chi Nhánh</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="https://anhtung.pancake.vn/pages/ban-giam-doc">Ban Giám Đốc</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/pages/gia-tri-cot-loi">Giá Trị Cốt Lõi</a>
                  
                </li>
                
                
              
            </ul>
          </div>
        
      
        
          <div class="data-lvl" data-lvl="1" data-type="nested-content" id="/blog">
            <div class="prev-node pos-relative pd-10">
              <span class="prev-node-btn"><i class="fa fa-caret-left" aria-hidden="true"></i></span>
              <div class="prev-node-title" id="node-title"></div>
            </div>
            <ul>
              
                
                <li class="sidebar-menu-item">
                  <a href="/blog/tips-thoi-trang">TIPS THỜI TRANG</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/blog/chuong-trinh-sale">CHƯƠNG TRÌNH SALE</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/blog/goc-gop-y">GÓC GÓP Ý</a>
                  
                </li>
                
                
              
                
                <li class="sidebar-menu-item">
                  <a href="/blog/tuyen-dung">TUYỂN DỤNG</a>
                  
                </li>
                
                
              
            </ul>
          </div>
        
      
    
  
    
  
    
  
    
  
  
  
    
      
        
      
        
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
        
      
        
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
        
      
        
          
            
              <div class="data-lvl" data-lvl="2" data-type="nested-content" id="/categories/be-trai">
                <div class="prev-node pos-relative pd-10">
                  <span class="prev-node-btn"><i class="fa fa-caret-left" aria-hidden="true"></i></span>
                  <div class="prev-node-title" id="node-title"></div>
                </div>
                <ul>
                  
                    <li class="sidebar-menu-item">
                      <a href="/categories/ao-so-mi-be-trai">Áo sơ mi</a>
                      
                      
                    </li>
                  
                    <li class="sidebar-menu-item">
                      <a href="/categories/ao-thun-be-trai">Áo thun</a>
                      
                      
                    </li>
                  
                    <li class="sidebar-menu-item">
                      <a href="/categories/quan-dai-be-trai">Quần dài</a>
                      
                      
                    </li>
                  
                    <li class="sidebar-menu-item">
                      <a href="/categories/quan-short-be-trai">Quần short</a>
                      
                      
                    </li>
                  
                    <li class="sidebar-menu-item">
                      <a href="/categories/set-bo-be-trai">Set bộ</a>
                      
                      
                    </li>
                  
                </ul>
              </div>
            
          
            
              <div class="data-lvl" data-lvl="2" data-type="nested-content" id="/categories/be-gai">
                <div class="prev-node pos-relative pd-10">
                  <span class="prev-node-btn"><i class="fa fa-caret-left" aria-hidden="true"></i></span>
                  <div class="prev-node-title" id="node-title"></div>
                </div>
                <ul>
                  
                    <li class="sidebar-menu-item">
                      <a href="/categories/so-mi-ao-kieu-be-gai">Sơ mi - Áo kiểu</a>
                      
                      
                    </li>
                  
                    <li class="sidebar-menu-item">
                      <a href="/categories/ao-thun-be-gai">Áo thun</a>
                      
                      
                    </li>
                  
                    <li class="sidebar-menu-item">
                      <a href="/categories/vay-dam-be-gai">Váy - Đầm</a>
                      
                      
                    </li>
                  
                    <li class="sidebar-menu-item">
                      <a href="/categories/quan-dai-be-gai">Quần dài</a>
                      
                      
                    </li>
                  
                    <li class="sidebar-menu-item">
                      <a href="/categories/quan-short-be-gai">Quần short</a>
                      
                      
                    </li>
                  
                    <li class="sidebar-menu-item">
                      <a href="/categories/set-bo-be-gai">Set bộ</a>
                      
                      
                    </li>
                  
                </ul>
              </div>
            
          
        
      
        
      
        
      
        
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
        
      
        
          
            
          
            
          
            
          
            
          
        
      
    
  
    
  
    
  
    
  
  
  
    
      
        
      
        
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
        
      
        
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
        
      
        
          
            
              
                
              
                
              
                
              
                
              
                
              
            
          
            
              
                
              
                
              
                
              
                
              
                
              
                
              
            
          
        
      
        
      
        
      
        
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
        
      
        
          
            
          
            
          
            
          
            
          
        
      
    
  
    
  
    
  
    
  
  
  
    
      
        
      
        
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
        
      
        
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
        
      
        
          
            
              
                
              
                
              
                
              
                
              
                
              
            
          
            
              
                
              
                
              
                
              
                
              
                
              
                
              
            
          
        
      
        
      
        
      
        
          
            
          
            
          
            
          
            
          
            
          
            
          
            
          
        
      
        
          
            
          
            
          
            
          
            
          
        
      
    
  
    
  
    
  
    
  
</div>
<div class="search-content hidden-md-up" id="search-content">
  <div class="search-wrapper ">
    <form class="search mgl-10">
      <input name="q" type="text" placeholder="Tìm kiếm…" autocomplete="off" class="input_search_mobile">
      <div class="search-icon" id="search-small">
        <i class="fa fa-search" aria-hidden="true"></i>
      </div>
    </form>
  </div>
</div>
<script>
   $("#search-small").click(function(){
    window.location.assign("/search?q="+$(".search .input_search_mobile").val())
   })
   
  $('.input_search_mobile').bind("enterKey",function(e){
   window.location.assign("/search?q="+$(".search .input_search_mobile").val())
  });
  $('.input_search_mobile').keyup(function(e){
      if(e.keyCode == 13)
      {
          $(this).trigger("enterKey");
      }
  });
</script>
<script>
  let toggleSearch = false
  let search = document.getElementById('search-content')
  let clickSearch = document.querySelector(".search-mobile")
  clickSearch.addEventListener('click', handleClickSearch)
  
  function handleClickSearch() {
    if(toggleSearch == false) {
      toggleSearch = true
      search.style.display = "block"
      search.style.height = "25px"
    } else {
      toggleSearch = false
      search.style.display = "none"
      search.style.height = "0px"
    }
  }
</script>
<script>
        obj = JSON.parse(document.getElementById('login-logout').innerText);
        if(obj != null) {
          document.querySelector('.hello').innerHTML = "Xin chào,";
          document.getElementsByClassName('un-name-login')[0].style.display = "block"
          document.getElementsByClassName('name-login')[0].style.display = "none"
          document.getElementsByClassName('log-out-mobile')[0].style.display = "block"
          let z = document.querySelectorAll('.log-in-mobile')
          for( let i = 0; i< z.length; i++) z[i].style.display = "none"
        } else {
          document.getElementsByClassName('log-out-mobile')[0].style.display = "none"
        }
</script>
<script>
  toggle = false
  let sidebar = document.getElementById('sidebar')
  let backdrop = document.getElementById('backdrop')
  sidebar.style.left= "-250px"
  backdrop.style.display = "none"
  document.addEventListener("click", function(e) {
    console.log(e, "eeeeeeeee")
    if (toggle && e.target != sidebar && !sidebar.contains(e.target)) {
      sidebar.style.transform = "translateX(-250px)"
      document.getElementById("backdrop").style.display = "none"
      toggle = false
    }
  })
  
  
 $(".sidebar").swipe({
    swipeStatus:function(event, phase, direction, distance, duration, fingers)
        {
            if (phase=="move" && direction =="left") {
                 sidebar.style.transform = "translateX(-250px)";
                 document.getElementById("backdrop").style.display = "none"
                  toggle = false
                 return false;
            }
        }
});
  
    
  let sidebarItems = document.getElementsByClassName("sidebar-menu-item")

  let openNodes = document.getElementsByClassName("open-node")
  const sidebarContainer = document.getElementById("sidebar-container")
  let state = []
  for (let i = 0; i < openNodes.length; i++) {
    openNodes[i].addEventListener("click", function(e) {
      let targetStr = this.attributes["data-target"].value;
      state.push(targetStr);
      let target = document.getElementById(targetStr)
      sidebarContainer.style.transform = "translateX(-250px)" 
      const lvl = target.attributes["data-lvl"].value;
      target.style.zIndex = `${lvl + 1}`
      target.style.transform = "translateX(0px)"
      target.querySelector(".prev-node-title").innerHTML = this.attributes["data-title"].value
      target.querySelector(".prev-node-btn").addEventListener("click", handleBack(target, this))
      currentNode = target;
    })
  }

  function handleBack(currentNode, prevSpan) {
    return function(event) {
      let prevNode = prevSpan.closest("div.data-lvl");
      currentNode.style.transform = "translateX(250px)";
      prevNode.style.transform = "translateX(0px)";
    }
  }

  let hamburger = document.getElementById("toogle-sidebar")
  hamburger.addEventListener("click", function(e) {
    sidebar.style.width = "250px"
    sidebar.style.transform = "translateX(250px)"
    
    document.getElementById("backdrop").style.display = "block"
    setTimeout(() => toggle = true, 100)
  })
</script>

<script>
  function calcWindowHeight() {
    let height = window.innerHeight;
    let sidebar = document.getElementById("sidebar")
    sidebar.style.height = height + "px"
    sidebar.style.overflowY = "scroll"
  }
  
  if (typeof window.onload == 'function') {
    let old = window.onload;
    window.onload = function() {
      // here
      calcWindowHeight()
      // calcFiltersPosition()
      if (typeof pf == "function") setTimeout(pf, 200)
    }
  } else {
    window.onload = function() {
      // here
      calcWindowHeight()
      // calcFiltersPosition()
    }
  }
  
  window.onscroll = function () { scrollFunction() };
  function scrollFunction() {
    let z = $(window).scrollTop();
    if (z >= 137) {
      $(".header-fixed").css("display","block")
    } else {
      $(".header-fixed").css("display","none")
    }
  }
</script>




  
  <!-- Start footer -->

<footer>
  <div class="wrapper">
    <div class="container">
      <div class="row">
      
        <div class="col lg-8 sm-12 mr-bottom-ft">
          <div class="footer-content handle-click-ft">
            <h5 class="address-title"><span="coulor: red"></span>LIÊN HỆ</span></h5>
             <div class="address-ctn">
                <p><span style="font-size: 12pt;"><strong>C&Ocirc;NG TY TNHH ĐẦU TƯ V&Agrave; SẢN XUẤT KIM HO&Agrave;NG VŨ</strong></span></p>
<p><span style="font-size: 12pt;"><strong>MSDN : 0402044624</strong></span></p>
<p><span style="font-size: 12pt;"><strong>Ng&agrave;y cấp : 07 th&aacute;ng 06 năm 2020</strong></span></p>
<p><span style="font-size: 12pt;"><strong>Nơi cấp : Sở Kế Hoạch V&agrave; Đầu Tư Th&agrave;nh Phố Đ&agrave; Nẵng</strong></span></p>
<p><span style="font-size: 12pt;"><strong>Địa chỉ : 182 T&ocirc; Hiệu - P. Ho&agrave; Minh - Q. Li&ecirc;n Chiểu - TP. Đ&agrave; Nẵng</strong></span></p>
<p><span style="font-size: 12pt;"><strong>SĐT : 0988.881.090</strong></span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
             </div>
          </div>
        </div>
       
        <div class="col lg-8 sm-12 mr-bottom-ft">
          <div class="footer-content handle-click-ft">
            <h5 class="address-title"><span style="strong"></span>HỖ TRỢ MUA HÀNG</span></h5>
            <div class="address-ctn" style="margin-top: 10px">
              
              
                <p><a href="https://anhtung.pancake.vn/pages/chinh-sach-bao-mat" class="hover-link-sp-sale"> <span style="padding-left: 5px; font-weight:600">-> Chính Sách Bảo Mật</a></span></p>
              
              
              
                <p><a href="https://anhtung.pancake.vn/pages/chinh-sach-bao-hanh-va-doi-tra" class="hover-link-sp-sale"> <span style="padding-left: 5px; font-weight:600">-> Chính Sách Bảo Hành Và Đổi Trả</a></span></p>
              
              
              
                <p><a href="https://anhtung.pancake.vn/pages/huong-dan-mua-hang" class="hover-link-sp-sale"> <span style="padding-left: 5px; font-weight:600">-> Hướng Dẫn Mua Hàng</a></span></p>
              
              
              
                <p><a href="https://anhtung.pancake.vn/pages/chinh-sach-hoi-vien" class="hover-link-sp-sale"> <span style="padding-left: 5px; font-weight:600">-> Chính Sách Thẻ Thành Viên</a></span></p>
              
              
              
                <p><a href="https://anhtung.pancake.vn/pages/danh-sach-dia-chi-cua-hang" class="hover-link-sp-sale"> <span style="padding-left: 5px; font-weight:600">-> Danh Sách Cửa Hàng</a></span></p>
              
              
              
                <p><a href="https://anhtung.pancake.vn/pages/chinh-sach-van-chuyen-va-thanh-toan" class="hover-link-sp-sale"> <span style="padding-left: 5px; font-weight:600">-> Chính Sách Vận Chuyển Và Thanh Toán</a></span></p>
              
              
            </div>
          </div>
        </div>
        
        <div class="col lg-8 sm-12 mgb-20">
            <div class="footer-content">
              
              <h5 class="address-title"><span style= general.color.color_highlight> KẾT NỐI <span></h5>
              <div class="icon-social">
                  <a href="https://www.facebook.com/fm.com.vn"> <span><i class="fab fa-facebook-square" aria-hidden="true"></i></span></a>
                  <a href="https://www.youtube.com/channel/UCQhO2S2frfU0ZlpkMhVw6Cg"><span><i class="fab fa-youtube" aria-hidden="true"></i></span></a>
                  <a href="https://instagram.com/fmstylefashion?utm_medium=copy_link"><span><i class="fab fa-instagram" aria-hidden="true"></i></span></a>
                  <a href="https://shopee.vn/fmstyle?categoryId=100011&amp;itemId=8837916903"><span><i class="fab fa-shopify"></i></span></a>
                  <a href="https://www.tiktok.com/@fm.com.vn?lang=vn"><span><i class="fab fa-tiktok"></i></span></a>
                  <a><span><i class="fa fa-shopee-square" aria-hidden="true"></i></span></a>
              </div>
              
              
              <h5 class="address-title"><span style="border-bottom: 1px solid #ed1d24;">FM Style Shop</span></h5>
                <div id="fb-root"></div>
                <script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v8.0&appId=760720474454006&autoLogAppEvents=1" nonce="ex5AeoBr"></script>
                <div class="fb-page"
                  data-href="https://www.facebook.com/fm.com.vn" 
                  data-width="340"
                  data-height="222"
                  data-hide-cover="false"
                  data-show-facepile="true">
                </div>
              
              
               <form action="/subscribe" enctype="multipart/form-data" method="post" accept-charset="UTF-8" >
<input type="hidden" name="_csrf_token" value="PlM6BjoAClYhC3hyDS43W1o3PBxwAXcgu7KAUQPngY1-iMo5ncrH8M2n">
<input type="hidden" name="utf8" value="✓">
                <div class="info-sale">
                  <h5 class="address-title" style="margin-top: 10px"><span style="border-bottom: 1px solid #ed1d24;">Đăng kí tư vấn miễn phí</span></h5>
                  <div class="footer-input">
                    <input placeholder="Nhập số điện thoại của bạn"  name="subscribe[email]" value="" >
                    <button><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
                  </div>
                  <p style="margin-top: 10px">Nhập số điện thoại để được tư vấn miễn phí và cập nhật các mẫu mới nhất nhé khách ơi</p>
                </div>
                </form>

              
              
            </div>
        </div>
         
      </div>
              <div class="logo-pancake">
          <span>Website design by:  
            <a href="https://pages.fm/">
              <img src="https://statics.pancake.vn/web-media/31/6d/84/5d/49161e1f43f146b40b503a1824e78bc72a6ee1d747c8160e8ad1deaf.svg">
            </a>
          </span>
      </div>
    </div>
  </div>
</footer>

<script>
  function myFunction(x) {
  if (x.matches) { // If media query matches
    let x = document.querySelectorAll('.handle-click-ft')
    for(let i = 0; i< x.length; i++) {
      x[i].addEventListener('click', handleClickFooter)}
    function handleClickFooter() {
    if(this.classList.contains('active')) {
    this.lastElementChild.style.display = "none";
    this.classList.remove('active');
    } else {
    this.classList.add('active');
    this.lastElementChild.style.display = "block"
   }}
  }
}

var x = window.matchMedia("(max-width: 570px)")
myFunction(x) // Call listener function at run time
x.addListener(myFunction) // Attach listener function on state changes
      
  
</script>


  
 <div class='scrolltop'>
    <div class='scroll icon'><i class="fa fa-4x fa-angle-up"></i></div>
    
    
    
</div>
<script>
  $(window).scroll(function() {
    if ($(this).scrollTop() > 50 ) {
        $('.scrolltop:hidden').stop(true, true).fadeIn();
    } else {
        $('.scrolltop').stop(true, true).fadeOut();
    }
});
$(function(){$(".scroll").click(function(){$("html,body").animate({scrollTop: 0},"1000");return false})})
</script>
<script>
   $('.lazy').Lazy();
</script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript" src="https://statics.pancake.vn/web-assets/1689/64/fb/c7/f8/jquery-lazy-min.js"></script>

<script>
  
  if (typeof window.onload == 'function') {
    let old = window.onload;
    window.onload = function() {
      old()
    }
  } else {
    window.onload = function() {
    }
  }
</script>

<!-- Load Facebook SDK for JavaScript -->
<div id="fb-root"></div>
<script>
  window.fbAsyncInit = function() {
    FB.init({
      xfbml            : true,
      version          : 'v8.0'
    });
  };

  (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<!-- Your Chat Plugin code -->
<div class="fb-customerchat" height="1px" width="60px"
  attribution=setup_tool
  page_id="115750760251251">
</div>

  <!-- End Script -->
<!-- Facebook custom events code -->
    <script type="text/javascript">
      
    </script>
<!-- End of Facebook custom events code -->
  
</body>

</html>

